#include "SmartConnectWiFi.h"

/*
Modified by Evan Wu 20181030
https://wyj-learning.blogspot.com/
*/

static const uint32_t Base_address = 0x3FA000;
static char buff[20][32]; 
static uint32_t Flash_n = 0; 
static int n = 0; 
static int CatchSSID = 404;
static char* CatchSSIDPtr = NULL; 
static char* CatchPASSPtr = NULL; 
static int ini_j = 1;
static const int S_LED = D4; //Led on board

/*----------------------------------------------------------------------------
  smartConnectWiFi
*----------------------------------------------------------------------------*/ 
bool smartConnectWiFi(){	
	Serial.println("smartConnectWiFi .....");
	pinMode(S_LED, OUTPUT);
	digitalWrite(S_LED, HIGH);

  if ( findWiFi() ) { 
	Serial.println("MATCH ! You already have matched WiFi SSID & PassWord in FLASH.");

	if ( !connectWiFi( CatchSSIDPtr, CatchPASSPtr, 40) ){ 
		Serial.println("You have matched WiFi SSID & PassWord. BUT NOT CONNECTED");
		Serial.println("Try another one in FLASH(if you have).");

			if ( ini_j > (2*Flash_n)) {
				Serial.println("Try all you have, but still NOT connect to WIFI."); 
				smartConfig(); // Normal smartConfig
			}
			else {
				smartConnectWiFi();
			}
		}
	}
	else { 
		Serial.println("You DONT have matched WiFi SSID & PassWord in FLASH.");     
		smartConfig();
	}

  if ( WiFi.status() == WL_CONNECTED ) { 
	Serial.println("WIFI CONNECTED"); 
	return true; 
  }
  else { 
	Serial.println("[ERROR] WIFI NOT CONNECTED"); 
	return false; 
  }
  digitalWrite(S_LED, LOW);
}

/*----------------------------------------------------------------------------
  findWiFi
 *----------------------------------------------------------------------------*/
bool findWiFi(){  
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  
  n = WiFi.scanNetworks();

  if (n == 0){
	Serial.println("No networks found !");
  }
  
  else
  {
	Serial.print(n);
	Serial.println(" networks found\n");
	for (int i = 0; i < n; ++i) {
		Serial.printf("%d. ", i);
		Serial.println( WiFi.SSID(i) );
		delay(10);
    }

	Serial.println("");

  }
  

  if ( !ESP.flashRead( Base_address, (uint32_t*)&Flash_n, 32 ) ) {
    } else { 
	Serial.printf( "addr: %p Flash_n : %d \n\n", Base_address, Flash_n ); 
	}

  if ( !(Flash_n <= 10) ) {
	Serial.println("No data in FLASH");
	return false;
  }

  for ( int j = 1; j <= (2*Flash_n); j++){
	if ( !ESP.flashRead( Base_address + j*32, (uint32_t*)(buff + j*32), 32 )){
	}else { 

	Serial.printf( "addr: %p content : %s \n", Base_address + j*32, buff + j*32 ); 

	}
	delay(200);
  } 

	Serial.println("");

	CatchSSID = 404;
	Serial.printf("ini_j = %d",ini_j);

	for ( int j = ini_j; j <= (2*Flash_n); j = j+2 ){
	  for ( int i = 0; i < n ; i++){
		
		if ( !(strcmp(WiFi.SSID(i).c_str(),(const char*)(buff + j*32))) ) {  
		CatchSSID = j;
		Serial.printf("\nCatchSSID = BASE+%d*32",CatchSSID);	 
		break;
		}
	  }
	  
	  if ( CatchSSID != 404 ) {
		ini_j = CatchSSID + 2;
		break;
	  }
	  
	}	

  if ( CatchSSID == 404 ) {
	Serial.println("\nNot found");
	return false; 
  }
  else {
      CatchSSIDPtr = (char*)(buff + CatchSSID*32);
      CatchPASSPtr = (char*)(buff + (CatchSSID+1)*32);
		Serial.printf("\nFind SSID : %s\r\n", CatchSSIDPtr );
		Serial.printf("Password (in Flash) : %s\r\n", CatchPASSPtr );      
	  return true;
  }
  
}

/*----------------------------------------------------------------------------
  connectWiFi
 *----------------------------------------------------------------------------*/
bool connectWiFi(char* ssid, char* pass, int tryNumber){
    
    int _try = 0;
    WiFi.mode(WIFI_STA);
    delay(500);
    WiFi.begin(ssid,pass);
	Serial.print("\nConnecting to ");
	Serial.println(ssid);

	
    while( WiFi.status() != WL_CONNECTED ){
      if( _try <= tryNumber){
        delay(500);
        _try++;
		Serial.print(_try);
      }
      else { 
		Serial.println("\nConnected Failed"); 
		return false;
		}
    }
	Serial.print("\nConnected success! IP address: ");
    Serial.println(WiFi.localIP());
    return true;
}

/*----------------------------------------------------------------------------
  smartConfig
 *----------------------------------------------------------------------------*/
void smartConfig(){
	Serial.println("Waiting for SmartConfig.");
	WiFi.beginSmartConfig();  
    
  while (!WiFi.smartConfigDone()) {
    delay(300);
	digitalWrite(S_LED,!digitalRead(S_LED));
	Serial.print(".");
  }
	Serial.println("\nSmartConfig done.");
	Serial.println("Recived SSID & WIFI");
	Serial.printf("SSID : %s\n", WiFi.SSID().c_str() );
	Serial.printf("PassWord : %s\n", WiFi.psk().c_str() );
	Serial.println("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
	digitalWrite(S_LED,!digitalRead(S_LED));
	Serial.print(".");
  }
    
  if ( WiFi.status() == WL_CONNECTED ) {
		Serial.println("\nWiFi connected successful ...");
		Serial.println("\nWrite SSID & PASSWORD in FLASH");
        String SSID_temp1 = WiFi.SSID();;
        String PASS_temp1 = WiFi.psk();
        char SSID_temp[32];
        char PASS_temp[32];
        strcpy(SSID_temp, SSID_temp1.c_str()); 
        strcpy(PASS_temp, PASS_temp1.c_str()); 
		uint32_t Flash_n_temp = Flash_n +1; 		  
		
		  

        if ( Flash_n <= 10 ){
			

			if ( int Duplicate = searchDuplicate(SSID_temp) ){
				Serial.println("[Case1]");				
				Serial.printf("Update \"%s\" Password to \"%s\"\n", SSID_temp, PASS_temp);
				
			  Erase_FLASH();
		  
			  if( !ESP.flashWrite( Base_address, (uint32_t*)(&Flash_n), 32 ) ) {
					Serial.printf( "[error] write addr: %p\n", Base_address );					
			  } else { 
				Serial.printf( "addr: %p write [%d] OK\n", Base_address, Flash_n ); 
			  }
			  
			  for ( int j = 1; j <= (2*Flash_n); j++){
				
				if( j != (Duplicate+1) ){
					if ( !ESP.flashWrite( Base_address + j*32, (uint32_t*)(buff + j*32), 32 )){
					}else { 
						Serial.printf( "addr: %p content : %s \n", Base_address + j*32, buff + j*32 ); 
					}
				}
				else{
					if ( !ESP.flashWrite( Base_address + j*32, (uint32_t*)PASS_temp, 32 )){
					}else { 
						Serial.printf( "addr: %p content : %s \n", Base_address + j*32, (uint32_t*)PASS_temp ); 
					}
				}
			  }
			}
			
			else {
				Serial.println("[Case2]");
				Erase_FLASH();
			  
   
			  if( !ESP.flashWrite( Base_address, (uint32_t*)(&Flash_n_temp), 32 ) ) {
				Serial.printf( "[error] write addr: %p\n", Base_address );

			  } else { 
				Serial.printf( "addr: %p write [%d] OK\n", Base_address, Flash_n_temp ); 
			  }


			  for ( int j = 1; j <= (2*Flash_n); j++){
				if ( !ESP.flashWrite( Base_address + j*32, (uint32_t*)(buff + j*32), 32 )){
				  }else { 
					Serial.printf( "addr: %p content : %s \n", Base_address + j*32, buff + j*32 ); 
				  }
			  }
			  
			  if( !ESP.flashWrite( Base_address + (2*Flash_n_temp-1)*32, (uint32_t*)SSID_temp, 32 ) ) {
					Serial.printf( "[error] write addr: %p\n", Base_address + (2*Flash_n_temp-1)*32 );
			  } else {
					Serial.printf( "addr: %p write [%s] OK\n", Base_address + (2*Flash_n_temp-1)*32, SSID_temp );
			    }	
			  
			  if( !ESP.flashWrite( Base_address + (2*Flash_n_temp)*32, (uint32_t*)PASS_temp, 32 ) ) {
					Serial.printf( "[error] write addr: %p\n", Base_address + (2*Flash_n_temp)*32 );
			  } else {
					Serial.printf( "addr: %p write [%s] OK\n", Base_address + (2*Flash_n_temp)*32, PASS_temp );
			  }
			}
        } 

        else{			
		  uint32_t Flash_n_temp = 1; 
			Serial.println("[Case3]");
			
          Erase_FLASH();       
          
          if( !ESP.flashWrite( Base_address, (uint32_t*)(&Flash_n_temp), 32 ) ) {
				Serial.printf( "[error] write addr: %p\n", Base_address );
          } else { 
			Serial.printf( "addr: %p write [%d] OK\n", Base_address, Flash_n_temp ); 
		  }
          
          if( !ESP.flashWrite( Base_address + 32, (uint32_t*)SSID_temp, 32 ) ) {
				Serial.printf( "[error] write addr: %p\n", Base_address + 32 );
          } else { 
			Serial.printf( "addr: %p write [%s] OK\n", Base_address + 32, SSID_temp ); 
		  }
          
          if( !ESP.flashWrite( Base_address + 64, (uint32_t*)PASS_temp, 32 ) ) {
				Serial.printf( "[error] write addr: %p\n", Base_address + 64 );
          } else { 
			Serial.printf( "addr: %p write [%s] OK\n", Base_address + 64, PASS_temp ); 
		  }
        } 

		Serial.println("RESTART");
		nodeRestart();
  }
  else {
		Serial.println("WiFi connected Faild !");
  }
}

/*----------------------------------------------------------------------------
  Erase_FLASH
 *----------------------------------------------------------------------------*/
void Erase_FLASH(){
	if( !ESP.flashEraseSector( Base_address >> 12 ) ) {
		Serial.println( "\n\nErase error\n");
        return;
    } else {
		Serial.println( "\n\nFlash Erase OK");
    }
}
/*----------------------------------------------------------------------------
  searchDuplicate
 *----------------------------------------------------------------------------*/
int searchDuplicate(char* SSID_temp){
		Serial.println("Finding ... ");	
	
	for ( int j = 1; j <= (2*Flash_n); j = j+2 ){		
		if ( !(strcmp(SSID_temp,(const char*)(buff + j*32))) ) {  
			Serial.printf("You had this SSID in FLASH (BASE+%d*32) before\n",j);
			return j;
		}
	}

return false;
}

/*----------------------------------------------------------------------------
  nodeRestart
*----------------------------------------------------------------------------*/
void nodeRestart(){
	  pinMode(D3,OUTPUT);
      pinMode(S_LED,OUTPUT);
      pinMode(D8,OUTPUT);
      
      digitalWrite(D3,HIGH);
      digitalWrite(S_LED,HIGH);
      digitalWrite(D8,LOW);
	  
      delay(1000);
	  Serial.println("MCU Restart");  
	  ESP.restart();
}
