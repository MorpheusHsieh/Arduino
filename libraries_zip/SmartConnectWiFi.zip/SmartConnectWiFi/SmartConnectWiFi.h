#ifndef SMARTCONNECTWIFI_h
#define SMARTCONNECTWIFI_h

/*
Modified by Evan Wu 20181030
https://wyj-learning.blogspot.com/
*/

#include <Arduino.h>
#include <stdio.h>
#include <stdlib.h>
#include <ESP8266WiFi.h>
#include <ESP.h>

bool smartConnectWiFi();
bool connectWiFi(char* ssid, char* pass, int tryNumber);
bool findWiFi();
void smartConfig();
void Erase_FLASH();
void nodeRestart();
int searchDuplicate(char* SSID_temp);

#endif