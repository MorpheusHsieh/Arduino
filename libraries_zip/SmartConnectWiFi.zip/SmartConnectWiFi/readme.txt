Modified by Evan Wu 20181030
https://wyj-learning.blogspot.com/

Memo

1. 板上 LED 燈閃爍表示正在等待手機的 SmartConfig

2. 若你的 WiFi 帳號密碼有更改過導致板子無法連上，板子會自動跳到 SmartConfig 模式，你只要重新在設定一次即可。注意，該做法會觸發 FLASH "整個"清空重寫

3. 最多記錄五組 WiFi 帳密

4. Erase_FLASH 可以清空 FLASH 所有已記錄的資料